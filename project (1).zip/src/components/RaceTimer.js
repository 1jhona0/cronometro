import { useState, useEffect, useRef } from 'react';

const RaceTimer = ({ onStart, onStop, onReset, isRunning, raceStarted }) => {
  const [time, setTime] = useState(0);
  const timerRef = useRef(null);

  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setTime(prev => prev + 10);
      }, 10);
    } else {
      clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [isRunning]);

  const handleReset = () => {
    setTime(0);
    onReset();
  };

  const formatTime = () => {
    const date = new Date(time);
    return date.toISOString().substr(11, 11);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">
        {raceStarted ? 'Cronómetro en Carrera' : 'Preparado'}
      </h2>
      <div className="text-4xl font-mono text-center mb-6">
        {formatTime()}
      </div>
      <div className="flex justify-center space-x-4">
        {!isRunning ? (
          <button
            onClick={onStart}
            disabled={!raceStarted}
            className={`${raceStarted ? 'bg-green-500 hover:bg-green-600' : 'bg-gray-400'} text-white font-bold py-2 px-6 rounded-lg transition-colors`}
          >
            Iniciar
          </button>
        ) : (
          <button
            onClick={onStop}
            className="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-6 rounded-lg transition-colors"
          >
            Detener
          </button>
        )}
        <button
          onClick={handleReset}
          className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-6 rounded-lg transition-colors"
        >
          Reiniciar
        </button>
      </div>
    </div>
  );
};

export default RaceTimer;