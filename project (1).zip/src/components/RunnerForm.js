import { useState } from 'react';

const RunnerForm = ({ currentRunner, onSave, onCancel }) => {
  const [runner, setRunner] = useState(currentRunner || {
    dorsal: '',
    name: '',
    team: '',
    handicap: 0
  });

  const handleChange = (e) => {
    setRunner({
      ...runner,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(runner);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">
        {currentRunner ? 'Editar Corredor' : 'Nuevo Corredor'}
      </h2>
      
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label htmlFor="dorsal" className="block text-gray-700 font-medium mb-2">
              Dorsal *
            </label>
            <input
              type="text"
              id="dorsal"
              name="dorsal"
              value={runner.dorsal}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
              Nombre
            </label>
            <input
              type="text"
              id="name"
              name="name"
              value={runner.name}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label htmlFor="team" className="block text-gray-700 font-medium mb-2">
              Equipo
            </label>
            <input
              type="text"
              id="team"
              name="team"
              value={runner.team}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label htmlFor="handicap" className="block text-gray-700 font-medium mb-2">
              Handicap (minutos)
            </label>
            <input
              type="number"
              id="handicap"
              name="handicap"
              min="0"
              step="1"
              value={runner.handicap}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="flex justify-end space-x-3">
          <button
            type="button"
            onClick={onCancel}
            className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-lg transition-colors"
          >
            Cancelar
          </button>
          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg transition-colors"
          >
            Guardar
          </button>
        </div>
      </form>
    </div>
  );
};

export default RunnerForm;