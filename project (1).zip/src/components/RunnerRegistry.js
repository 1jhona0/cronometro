import { useState } from 'react';

const RunnerRegistry = ({ runners, onAddRunner, onStartRace }) => {
  const [runner, setRunner] = useState({
    dorsal: '',
    name: '',
    team: '',
    startOffset: 0
  });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setRunner({
      ...runner,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    if (!runner.dorsal.trim()) {
      setError('El dorsal es requerido');
      return;
    }

    if (runners.some(r => r.dorsal === runner.dorsal)) {
      setError('Este dorsal ya está registrado');
      return;
    }

    onAddRunner({
      ...runner,
      startOffset: Number(runner.startOffset)
    });

    setRunner({
      dorsal: '',
      name: '',
      team: '',
      startOffset: 0
    });
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Registro de Corredores</h2>
      
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label htmlFor="dorsal" className="block text-gray-700 font-medium mb-2">
              Dorsal *
            </label>
            <input
              type="text"
              id="dorsal"
              name="dorsal"
              value={runner.dorsal}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
              Nombre
            </label>
            <input
              type="text"
              id="name"
              name="name"
              value={runner.name}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label htmlFor="team" className="block text-gray-700 font-medium mb-2">
              Equipo
            </label>
            <input
              type="text"
              id="team"
              name="team"
              value={runner.team}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label htmlFor="startOffset" className="block text-gray-700 font-medium mb-2">
              Desventaja (minutos)
            </label>
            <input
              type="number"
              id="startOffset"
              name="startOffset"
              min="0"
              step="1"
              value={runner.startOffset}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {error && <p className="text-red-500 mb-4">{error}</p>}

        <div className="flex justify-between">
          <button
            type="submit"
            className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-6 rounded-lg transition-colors"
          >
            Registrar Corredor
          </button>
          
          <button
            type="button"
            onClick={onStartRace}
            disabled={runners.length === 0}
            className={`${runners.length === 0 ? 'bg-gray-400' : 'bg-green-500 hover:bg-green-600'} text-white font-bold py-2 px-6 rounded-lg transition-colors`}
          >
            Iniciar Competencia
          </button>
        </div>
      </form>
    </div>
  );
};

export default RunnerRegistry;