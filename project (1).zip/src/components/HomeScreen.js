const HomeScreen = () => {
  return (
    <div className="max-w-5xl mx-auto py-12 px-4">
      <div className="bg-white p-10 rounded-xl shadow-2xl border border-gray-100">
        <div className="text-center mb-10">
          <h1 className="text-5xl font-extrabold text-gray-900 mb-4 leading-tight">
            Bienvenido a <span className="text-blue-600">CronoRace Pro</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Tu solución definitiva para el cronometraje de competencias de contra reloj.
            Precisión, control y resultados al instante.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="bg-blue-50 p-6 rounded-lg shadow-md border border-blue-100 transform hover:scale-105 transition-transform duration-300">
            <div className="text-blue-600 text-4xl mb-3">
              {/* SVG Icon for Registration */}
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor" className="w-10 h-10 mx-auto">
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 7.5v3m0 0v3m0-3h3m-3 0h-3m-2.25-4.5H12a2.25 2.25 0 00-2.25 2.25v4.5a2.25 2.25 0 002.25 2.25h.75m-2.25-4.5h.75m-7.5 0h.75m-2.25-4.5H9a2.25 2.25 0 012.25-2.25v4.5a2.25 2.25 0 01-2.25 2.25H9m-3.75-9l-1.5 1.5V21.75A2.25 2.25 0 006 24h12a2.25 2.25 0 002.25-2.25V10.5M16.5 7.5V3a2.25 2.25 0 00-2.25-2.25H3.75A2.25 2.25 0 001.5 3v13.5A2.25 2.25 0 003.75 18h11.25" />
              </svg>
            </div>
            <h3 className="font-bold text-xl text-blue-800 mb-2 text-center">1. Registro Completo</h3>
            <p className="text-sm text-gray-700 text-center">
              Gestiona corredores con dorsal, nombre, equipo y handicap.
            </p>
          </div>
          <div className="bg-green-50 p-6 rounded-lg shadow-md border border-green-100 transform hover:scale-105 transition-transform duration-300">
            <div className="text-green-600 text-4xl mb-3">
              {/* SVG Icon for Race Control */}
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor" className="w-10 h-10 mx-auto">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="font-bold text-xl text-green-800 mb-2 text-center">2. Control de Carrera</h3>
            <p className="text-sm text-gray-700 text-center">
              Cronometraje de alta precisión y registro de llegadas al instante.
            </p>
          </div>
          <div className="bg-purple-50 p-6 rounded-lg shadow-md border border-purple-100 transform hover:scale-105 transition-transform duration-300">
            <div className="text-purple-600 text-4xl mb-3">
              {/* SVG Icon for Results */}
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor" className="w-10 h-10 mx-auto">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125l7.25 7.25 7.25-7.25m-14.5 0a.75.75 0 010-1.5h14.5a.75.75 0 010 1.5m-14.5 0v-6.75a.75.75 0 01.75-.75h13a.75.75 0 01.75.75v6.75" />
              </svg>
            </div>
            <h3 className="font-bold text-xl text-purple-800 mb-2 text-center">3. Resultados y Datos</h3>
            <p className="text-sm text-gray-700 text-center">
              Visualiza podios, exporta a CSV y gestiona tus datos de forma segura.
            </p>
          </div>
        </div>

        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-lg shadow-inner">
          <h3 className="font-bold text-yellow-800 text-lg mb-2 flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor" className="w-6 h-6 mr-2">
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.38 3.375 2.07 3.375h14.006c1.69 0 2.936-1.875 2.069-3.376L12.72 3.49c-.795-1.379-2.803-1.379-3.598 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
            </svg>
            ¡Importante!
          </h3>
          <p className="text-gray-700">
            Todos tus datos se guardan automáticamente en tu navegador. Para asegurar la información o transferirla,
            utiliza las opciones de "Exportar" e "Importar" en la sección de "Gestión de Datos".
          </p>
        </div>
      </div>
    </div>
  );
};

export default HomeScreen;

// DONE