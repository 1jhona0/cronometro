import { useState, useEffect } from 'react';

const AppNavigation = ({ activeView, onChangeView, isTimerRunning }) => {
  const [currentView, setCurrentView] = useState(activeView);

  useEffect(() => {
    setCurrentView(activeView);
  }, [activeView]);

  const handleNavigation = (view) => {
    setCurrentView(view);
    onChangeView(view);
  };

  const navItems = [
    { id: 'home', label: 'Inicio' },
    { id: 'register', label: 'Registrar Competencia' },
    { id: 'race', label: 'Control de Carrera' },
    { id: 'data', label: 'Gestión de Datos' },
  ];

  return (
    <nav className="bg-gray-900 text-white shadow-lg">
      <div className="container mx-auto px-4 py-3 flex justify-center items-center relative">
        <div className="flex space-x-4">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavigation(item.id)}
              className={`
                px-4 py-2 rounded-full text-sm font-medium transition-all duration-300
                flex items-center justify-center
                ${currentView === item.id 
                  ? 'bg-blue-600 text-white shadow-md' 
                  : 'bg-gray-800 hover:bg-gray-700 text-gray-300 hover:text-white'
                }
              `}
            >
              {item.label}
            </button>
          ))}
        </div>
        {isTimerRunning && (
          <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center space-x-2 bg-green-600 text-white text-xs px-3 py-1 rounded-full shadow-md">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
            </span>
            <span>Cronómetro Activo</span>
          </div>
        )}
      </div>
    </nav>
  );
};

export default AppNavigation;