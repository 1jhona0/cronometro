const RunnersList = ({ runners, onRemoveRunner }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md mt-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Corredores Registrados ({runners.length})</h2>
      
      {runners.length === 0 ? (
        <p className="text-gray-500">No hay corredores registrados</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dorsal</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Equipo</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Desventaja</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acción</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {runners.map((runner, index) => (
                <tr key={runner.dorsal}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{runner.dorsal}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{runner.name || '-'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{runner.team || '-'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{runner.startOffset || 0} min</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <button
                      onClick={() => onRemoveRunner(runner.dorsal)}
                      className="text-red-500 hover:text-red-700"
                    >
                      Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default RunnersList;