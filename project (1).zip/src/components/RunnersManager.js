import { useState } from 'react';
import RunnerForm from './RunnerForm';

const RunnersManager = ({ runners, onAddRunner, onUpdateRunner, onDeleteRunner, onStartRace }) => {
  const [editingRunner, setEditingRunner] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredRunners = runners.filter(runner =>
    runner.dorsal.includes(searchTerm) ||
    runner.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    runner.team.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSave = (runner) => {
    if (editingRunner) {
      onUpdateRunner(runner);
    } else {
      onAddRunner(runner);
    }
    setShowForm(false);
    setEditingRunner(null);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Gestión de Corredores</h2>
        <button
          onClick={() => {
            setEditingRunner(null);
            setShowForm(true);
          }}
          className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-lg transition-colors"
        >
          Nuevo Corredor
        </button>
      </div>

      <div className="mb-4">
        <input
          type="text"
          placeholder="Buscar corredor..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {showForm && (
        <RunnerForm
          currentRunner={editingRunner}
          onSave={handleSave}
          onCancel={() => {
            setShowForm(false);
            setEditingRunner(null);
          }}
        />
      )}

      <div className="overflow-x-auto mt-6">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dorsal</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Equipo</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Handicap</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredRunners.map((runner) => (
              <tr key={runner.dorsal}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{runner.dorsal}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{runner.name || '-'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{runner.team || '-'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{runner.handicap || 0} min</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 space-x-2">
                  <button
                    onClick={() => {
                      setEditingRunner(runner);
                      setShowForm(true);
                    }}
                    className="text-blue-500 hover:text-blue-700"
                  >
                    Editar
                  </button>
                  <button
                    onClick={() => onDeleteRunner(runner.dorsal)}
                    className="text-red-500 hover:text-red-700"
                  >
                    Eliminar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {runners.length > 0 && (
        <div className="mt-6 flex justify-end">
          <button
            onClick={onStartRace}
            className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-2 px-6 rounded-lg transition-colors"
          >
            Iniciar Competencia
          </button>
        </div>
      )}
    </div>
  );
};

export default RunnersManager;