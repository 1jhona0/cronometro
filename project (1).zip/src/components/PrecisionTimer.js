import { useState, useEffect, useRef } from 'react';

const PrecisionTimer = ({ currentTime }) => {
  const formatTime = (ms) => {
    if (ms < 0) ms = 0; // Asegurarse de que no haya tiempos negativos
    const date = new Date(ms);
    const hours = date.getUTCHours().toString().padStart(2, '0');
    const minutes = date.getUTCMinutes().toString().padStart(2, '0');
    const seconds = date.getUTCSeconds().toString().padStart(2, '0');
    const milliseconds = Math.floor(date.getUTCMilliseconds() / 100).toString();
    return `${hours !== '00' ? hours + ':' : ''}${minutes}:${seconds}.${milliseconds}`;
  };

  return (
    <div className="text-center mb-6">
      <div className="text-5xl font-mono bg-gray-900 text-green-400 py-4 px-8 rounded-lg inline-block">
        {formatTime(currentTime)}
      </div>
    </div>
  );
};

export default PrecisionTimer;