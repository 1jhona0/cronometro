import { useState, useEffect, useCallback } from 'react';
// PrecisionTimer ya no se importa aquí
// saveRaceData ya no se importa aquí, se maneja en App.js

const RaceControl = ({ runners, onRecordFinish, onResetRace, isTimerRunning, onTimerRunningChange, currentRaceTime }) => {
  const [dorsalInput, setDorsalInput] = useState('');
  const [message, setMessage] = useState({ text: '', type: '' });
  const [playSound, setPlaySound] = useState(true);

  const handleRecordFinish = useCallback(() => {
    if (!dorsalInput) {
      showMessage('Ingrese un dorsal', 'error');
      return;
    }

    const runner = runners.find(r => r.dorsal === dorsalInput);
    if (!runner) {
      showMessage('Dorsal no registrado', 'error');
      return;
    }

    if (runner.finishTime) {
      showMessage('Este dorsal ya terminó', 'warning');
      return;
    }

    const finishTime = currentRaceTime; // Usa el tiempo global
    const handicapTime = (runner.handicap || 0) * 60000;
    const finalTime = finishTime - handicapTime;

    onRecordFinish(runner.dorsal, finishTime, finalTime);
    setDorsalInput('');
    showMessage(`Llegada registrada: Dorsal ${runner.dorsal}`, 'success');
    
    if (playSound) {
      const audio = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-achievement-bell-600.mp3');
      audio.volume = 0.3;
      audio.play().catch(e => console.log('Audio error:', e));
    }
  }, [dorsalInput, runners, currentRaceTime, playSound, onRecordFinish]);

  const showMessage = (text, type) => {
    setMessage({ text, type });
    setTimeout(() => setMessage({ text: '', type: '' }), 3000);
  };

  const confirmReset = () => {
    if (window.confirm('¿Estás seguro de reiniciar TODOS los tiempos de la carrera?\n\nEsta acción no se puede deshacer.')) {
      onResetRace();
      showMessage('Carrera reiniciada - Tiempos borrados', 'warning');
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Control de Carrera</h2>
      
      <div className="flex justify-between items-center mb-6">
        <div>
          <span className="font-semibold">Estado: </span>
          <span className={isTimerRunning ? 'text-green-500' : 'text-gray-500'}>
            {isTimerRunning ? 'EN CURSO' : 'DETENIDO'}
          </span>
        </div>
        
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={playSound}
            onChange={() => setPlaySound(!playSound)}
            className="rounded text-blue-500"
          />
          <span>Sonido de llegada</span>
        </label>
      </div>

      {/* PrecisionTimer ya no se renderiza aquí */}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className="space-y-4">
          <div className="flex space-x-2">
            <button
              onClick={() => onTimerRunningChange(true)}
              disabled={isTimerRunning}
              className={`flex-1 ${isTimerRunning ? 'bg-gray-400' : 'bg-green-500 hover:bg-green-600'} text-white font-bold py-2 px-4 rounded-lg transition-colors`}
            >
              Iniciar
            </button>
            <button
              onClick={() => onTimerRunningChange(false)}
              disabled={!isTimerRunning}
              className={`flex-1 ${!isTimerRunning ? 'bg-gray-400' : 'bg-red-500 hover:bg-red-600'} text-white font-bold py-2 px-4 rounded-lg transition-colors`}
            >
              Detener
            </button>
          </div>
          
          <button
            onClick={confirmReset}
            className="w-full bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded-lg transition-colors"
          >
            Reiniciar Tiempos
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Registrar Llegada</label>
            <div className="flex space-x-2">
              <input
                type="text"
                value={dorsalInput}
                onChange={(e) => setDorsalInput(e.target.value)}
                placeholder="Ingrese dorsal"
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                onKeyPress={(e) => e.key === 'Enter' && handleRecordFinish()}
              />
              <button
                onClick={handleRecordFinish}
                className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-2 px-4 rounded-lg transition-colors"
              >
                Registrar
              </button>
            </div>
          </div>
        </div>
      </div>

      {message.text && (
        <div className={`mt-2 p-3 rounded text-sm ${
          message.type === 'error' ? 'bg-red-100 text-red-700' :
          message.type === 'warning' ? 'bg-yellow-100 text-yellow-700' :
          'bg-green-100 text-green-700'
        }`}>
          {message.text}
        </div>
      )}

      <div className="mt-4 grid grid-cols-3 gap-2 text-center">
        <div className="bg-gray-50 p-2 rounded">
          <div className="text-xs text-gray-500">Corredores</div>
          <div className="font-bold">{runners.length}</div>
        </div>
        <div className="bg-gray-50 p-2 rounded">
          <div className="text-xs text-gray-500">Terminados</div>
          <div className="font-bold">{runners.filter(r => r.finishTime).length}</div>
        </div>
        <div className="bg-gray-50 p-2 rounded">
          <div className="text-xs text-gray-500">Pendientes</div>
          <div className="font-bold">{runners.filter(r => !r.finishTime).length}</div>
        </div>
      </div>
    </div>
  );
};

export default RaceControl;