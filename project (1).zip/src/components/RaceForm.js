import { useState } from 'react';

const RaceForm = ({ onAddRunner, runners, isRunning }) => {
  const [dorsal, setDorsal] = useState('');
  const [startOffset, setStartOffset] = useState(0);
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    if (!dorsal.trim()) {
      setError('Ingrese un número de dorsal');
      return;
    }

    if (runners.some(r => r.dorsal === dorsal)) {
      setError('Este dorsal ya está registrado');
      return;
    }

    if (!isRunning) {
      setError('El cronómetro no está iniciado');
      return;
    }

    onAddRunner(dorsal, startOffset);
    setDorsal('');
    setStartOffset(0);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md">
      <div className="mb-4">
        <label htmlFor="dorsal" className="block text-gray-700 font-medium mb-2">
          Número de Dorsal
        </label>
        <input
          type="text"
          id="dorsal"
          value={dorsal}
          onChange={(e) => setDorsal(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="Ej: 42"
        />
      </div>
      
      <div className="mb-4">
        <label htmlFor="startOffset" className="block text-gray-700 font-medium mb-2">
          Tiempo de desventaja (minutos)
        </label>
        <input
          type="number"
          id="startOffset"
          min="0"
          step="1"
          value={startOffset}
          onChange={(e) => setStartOffset(Number(e.target.value))}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="Ej: 2 (minutos de desventaja)"
        />
      </div>

      {error && <p className="text-red-500 mb-4">{error}</p>}

      <button
        type="submit"
        className="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg transition-colors"
      >
        Registrar Corredor
      </button>
    </form>
  );
};

export default RaceForm;