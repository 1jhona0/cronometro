const RaceResults = ({ runners }) => {
  // Añadir tiempos finales calculados a cada corredor
  const runnersWithTimes = runners.map(runner => {
    const finishTime = runner.finishTime || 0;
    const startOffsetMs = (runner.startOffset || 0) * 60000;
    const finalTime = finishTime - startOffsetMs;
    
    return {
      ...runner,
      finalTime,
      formattedFinalTime: formatTime(finalTime),
      formattedFinishTime: formatTime(finishTime)
    };
  });

  // Ordenar por tiempo final
  const sortedRunners = [...runnersWithTimes].sort((a, b) => a.finalTime - b.finalTime);

  function formatTime(ms) {
    if (ms < 0) return '00:00:00';
    const date = new Date(ms);
    return date.toISOString().substr(11, 8);
  }

  return (
    <div className="mt-8 bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Resultados Finales</h2>
      
      {sortedRunners.length === 0 ? (
        <p className="text-gray-500">No hay resultados aún</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Pos</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dorsal</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Equipo</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tiempo</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Desventaja</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tiempo Final</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {sortedRunners.map((runner, index) => (
                <tr 
                  key={runner.dorsal} 
                  className={index < 3 ? 
                    (index === 0 ? 'bg-yellow-50' : 
                     index === 1 ? 'bg-gray-50' : 
                     'bg-orange-50') : ''}
                >
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {index + 1}
                    {index === 0 && <span className="ml-2 text-yellow-500">🥇</span>}
                    {index === 1 && <span className="ml-2 text-gray-500">🥈</span>}
                    {index === 2 && <span className="ml-2 text-orange-500">🥉</span>}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{runner.dorsal}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{runner.name || '-'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{runner.team || '-'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {runner.formattedFinishTime || '-'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {runner.startOffset || 0} min
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">
                    {runner.formattedFinalTime}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default RaceResults;