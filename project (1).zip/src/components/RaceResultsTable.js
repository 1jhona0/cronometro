import { useState } from 'react';

const RaceResultsTable = ({ runners, onExportResults }) => {
  const [sortConfig, setSortConfig] = useState({ key: 'finalTime', direction: 'ascending' });

  const sortedRunners = [...runners]
    .filter(r => r.finishTime !== undefined)
    .sort((a, b) => {
      if (a[sortConfig.key] < b[sortConfig.key]) {
        return sortConfig.direction === 'ascending' ? -1 : 1;
      }
      if (a[sortConfig.key] > b[sortConfig.key]) {
        return sortConfig.direction === 'ascending' ? 1 : -1;
      }
      return 0;
    });

  const requestSort = (key) => {
    let direction = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  const formatTime = (ms) => {
    if (ms < 0) return '00:00.0';
    const date = new Date(ms);
    const minutes = date.getUTCMinutes().toString().padStart(2, '0');
    const seconds = date.getUTCSeconds().toString().padStart(2, '0');
    const milliseconds = Math.floor(date.getUTCMilliseconds() / 100).toString();
    return `${minutes}:${seconds}.${milliseconds}`;
  };

  const exportToCSV = () => {
    const headers = ['Posición,Dorsal,Nombre,Equipo,Tiempo,Handicap,Tiempo Final'];
    const csvContent = [
      ...headers,
      ...sortedRunners.map((runner, index) => 
        `${index + 1},${runner.dorsal},"${runner.name || ''}","${runner.team || ''}",${formatTime(runner.finishTime)},${runner.handicap || 0} min,${formatTime(runner.finalTime)}`
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', `resultados_carrera_${new Date().toISOString().slice(0,10)}.csv`);
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mt-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-gray-800">Resultados</h2>
        <button
          onClick={exportToCSV}
          className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-lg transition-colors text-sm"
        >
          Exportar a CSV
        </button>
      </div>
      
      {sortedRunners.length === 0 ? (
        <p className="text-gray-500">No hay resultados aún</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => requestSort('position')}
                >
                  Pos
                </th>
                <th 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => requestSort('dorsal')}
                >
                  Dorsal
                </th>
                <th 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => requestSort('name')}
                >
                  Nombre
                </th>
                <th 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => requestSort('team')}
                >
                  Equipo
                </th>
                <th 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => requestSort('finishTime')}
                >
                  Tiempo
                </th>
                <th 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => requestSort('handicap')}
                >
                  Handicap
                </th>
                <th 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => requestSort('finalTime')}
                >
                  Tiempo Final
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {sortedRunners.map((runner, index) => (
                <tr 
                  key={runner.dorsal} 
                  className={index < 3 ? 
                    (index === 0 ? 'bg-yellow-50' : 
                     index === 1 ? 'bg-gray-50' : 
                     'bg-orange-50') : ''}
                >
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {index + 1}
                    {index === 0 && <span className="ml-2 text-yellow-500">🥇</span>}
                    {index === 1 && <span className="ml-2 text-gray-500">🥈</span>}
                    {index === 2 && <span className="ml-2 text-orange-500">🥉</span>}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{runner.dorsal}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{runner.name || '-'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{runner.team || '-'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {formatTime(runner.finishTime)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {runner.handicap || 0} min
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">
                    {formatTime(runner.finalTime)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default RaceResultsTable;

// DONE