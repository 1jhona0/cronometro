import { useState } from 'react';
import { exportAllData, importData } from '../utils/storage';

const DataManagement = ({ onImportSuccess }) => {
  const [importJson, setImportJson] = useState('');
  const [message, setMessage] = useState({ text: '', type: '' });

  const handleExport = () => {
    const data = exportAllData();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `cronorace_backup_${new Date().toISOString().slice(0,10)}.json`);
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showMessage('Datos exportados correctamente', 'success');
  };

  const handleImport = () => {
    if (importData(importJson)) {
      showMessage('Datos importados correctamente', 'success');
      onImportSuccess();
    } else {
      showMessage('Error al importar datos - Formato incorrecto', 'error');
    }
  };

  const showMessage = (text, type) => {
    setMessage({ text, type });
    setTimeout(() => setMessage({ text: '', type: '' }), 5000);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mt-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Gestión de Datos</h2>
      
      <div className="space-y-6">
        <div>
          <h3 className="font-semibold text-gray-700 mb-2">Exportar Datos Completos</h3>
          <button
            onClick={handleExport}
            className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-lg transition-colors"
          >
            Exportar Backup Completo (.json)
          </button>
          <p className="text-sm text-gray-500 mt-2">Incluye todos los corredores y estado actual de la carrera</p>
        </div>
        
        <div>
          <h3 className="font-semibold text-gray-700 mb-2">Importar Datos</h3>
          <textarea
            value={importJson}
            onChange={(e) => setImportJson(e.target.value)}
            placeholder="Pega aquí el JSON de backup"
            className="w-full h-32 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 mb-2 font-mono text-sm"
          />
          <button
            onClick={handleImport}
            disabled={!importJson}
            className={`${!importJson ? 'bg-gray-400' : 'bg-green-500 hover:bg-green-600'} text-white font-bold py-2 px-4 rounded-lg transition-colors`}
          >
            Importar Datos
          </button>
          <p className="text-sm text-gray-500 mt-2">Importará corredores y estado de carrera</p>
        </div>
      </div>
      
      {message.text && (
        <div className={`mt-4 p-3 rounded text-sm ${
          message.type === 'error' ? 'bg-red-100 text-red-700' :
          'bg-green-100 text-green-700'
        }`}>
          {message.text}
        </div>
      )}
    </div>
  );
};

export default DataManagement;