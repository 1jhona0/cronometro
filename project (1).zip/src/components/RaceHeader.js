const RaceHeader = () => {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-blue-800 py-6 px-4 shadow-lg">
      <h1 className="text-3xl font-bold text-white text-center">CronoRace</h1>
      <p className="text-blue-100 text-center mt-2">Control de Tiempos - Competencia Contra Reloj</p>
    </header>
  );
};

export default RaceHeader;