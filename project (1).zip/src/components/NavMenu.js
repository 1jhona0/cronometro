import { NavLink } from 'react-router-dom';

const NavMenu = () => {
  return (
    <nav className="bg-gray-800 text-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex space-x-4">
            <NavLink 
              to="/" 
              exact
              className="px-3 py-2 rounded-md text-sm font-medium hover:bg-gray-700 transition"
              activeClassName="bg-gray-900"
            >
              Inicio
            </NavLink>
            <NavLink
              to="/registro"
              className="px-3 py-2 rounded-md text-sm font-medium hover:bg-gray-700 transition"
              activeClassName="bg-gray-900"
            >
              Registrar Competencia
            </NavLink>
            <NavLink
              to="/carrera"
              className="px-3 py-2 rounded-md text-sm font-medium hover:bg-gray-700 transition"
              activeClassName="bg-gray-900"
            >
              Control de Carrera
            </NavLink>
            <NavLink
              to="/gestion"
              className="px-3 py-2 rounded-md text-sm font-medium hover:bg-gray-700 transition"
              activeClassName="bg-gray-900"
            >
              Gestión de Datos
            </NavLink>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default NavMenu;