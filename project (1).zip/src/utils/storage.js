export const saveRaceData = (data) => {
  try {
    localStorage.setItem('cronorace_data', JSON.stringify(data));
    localStorage.setItem('cronorace_last_save', new Date().toISOString());
  } catch (e) {
    console.error('Error saving data:', e);
  }
};

export const loadRaceData = () => {
  try {
    const data = localStorage.getItem('cronorace_data');
    return data ? JSON.parse(data) : null;
  } catch (e) {
    console.error('Error loading data:', e);
    return null;
  }
};

export const exportAllData = () => {
  const data = loadRaceData();
  return JSON.stringify(data, null, 2);
};

export const importData = (jsonData) => {
  try {
    const data = JSON.parse(jsonData);
    if (data && data.runners) {
      saveRaceData(data);
      return true;
    }
    return false;
  } catch (e) {
    console.error('Error importing data:', e);
    return false;
  }
};