import { useState, useEffect, useRef } from 'react';
import { loadRaceData, saveRaceData } from './utils/storage';
import AppNavigation from './components/AppNavigation';
import HomeScreen from './components/HomeScreen';
import RunnersManager from './components/RunnersManager';
import RaceControl from './components/RaceControl';
import DataManagement from './components/DataManagement';
import RaceHeader from './components/RaceHeader';
import RaceResultsTable from './components/RaceResultsTable';
import PrecisionTimer from './components/PrecisionTimer';

const App = () => {
  const [runners, setRunners] = useState([]);
  const [raceState, setRaceState] = useState({
    isRunning: false,
    currentTime: 0,
    startTime: null, // Nuevo estado para el tiempo de inicio
    playSound: true,
    activeView: 'home'
  });

  const animationFrameRef = useRef(null);

  // Cargar datos al iniciar
  useEffect(() => {
    const loadedData = loadRaceData();
    if (loadedData) {
      setRunners(loadedData.runners || []);
      setRaceState(prev => ({
        ...prev,
        isRunning: loadedData.raceState?.isRunning || false,
        currentTime: loadedData.raceState?.currentTime || 0,
        startTime: loadedData.raceState?.startTime || null, // Cargar startTime
        playSound: loadedData.raceState?.playSound ?? true,
        activeView: loadedData.raceState?.activeView || 'home'
      }));
    }
  }, []);

  // Guardar datos cuando cambian
  useEffect(() => {
    saveRaceData({
      runners,
      raceState: {
        isRunning: raceState.isRunning,
        currentTime: raceState.currentTime,
        startTime: raceState.startTime, // Guardar startTime
        playSound: raceState.playSound,
        activeView: raceState.activeView
      }
    });
  }, [runners, raceState]);

  // Lógica del cronómetro
  useEffect(() => {
    const updateTimer = (timestamp) => {
      if (raceState.isRunning && raceState.startTime !== null) {
        const elapsed = timestamp - raceState.startTime;
        setRaceState(prev => ({ ...prev, currentTime: elapsed }));
      }
      animationFrameRef.current = requestAnimationFrame(updateTimer);
    };

    if (raceState.isRunning) {
      // Si el cronómetro se inicia y no hay startTime, lo establecemos
      if (raceState.startTime === null) {
        setRaceState(prev => ({ ...prev, startTime: performance.now() }));
      }
      animationFrameRef.current = requestAnimationFrame(updateTimer);
    } else {
      cancelAnimationFrame(animationFrameRef.current);
    }

    return () => cancelAnimationFrame(animationFrameRef.current);
  }, [raceState.isRunning, raceState.startTime]);

  const changeView = (view) => {
    setRaceState(prev => ({
      ...prev,
      activeView: view
    }));
  };

  const addRunner = (newRunner) => {
    setRunners(prev => [...prev, newRunner]);
  };

  const updateRunner = (updatedRunner) => {
    setRunners(prev => 
      prev.map(r => 
        r.dorsal === updatedRunner.dorsal ? updatedRunner : r
      )
    );
  };

  const deleteRunner = (dorsal) => {
    if (window.confirm(`¿Eliminar permanentemente al corredor ${dorsal}?`)) {
      setRunners(prev => prev.filter(r => r.dorsal !== dorsal));
    }
  };

  const recordFinish = (dorsal, finishTime, finalTime) => {
    setRunners(prev => 
      prev.map(r => 
        r.dorsal === dorsal 
          ? { ...r, finishTime, finalTime } 
          : r
      )
    );
  };

  const resetRaceData = () => {
    setRunners(prev => 
      prev.map(r => ({
        ...r,
        finishTime: undefined,
        finalTime: undefined
      }))
    );
    setRaceState(prev => ({
      ...prev,
      isRunning: false,
      currentTime: 0,
      startTime: null // Reiniciar startTime también
    }));
  };

  const handleImportSuccess = () => {
    const loadedData = loadRaceData();
    if (loadedData) {
      setRunners(loadedData.runners || []);
      setRaceState(prev => ({
        ...prev,
        isRunning: loadedData.raceState?.isRunning || false,
        currentTime: loadedData.raceState?.currentTime || 0,
        startTime: loadedData.raceState?.startTime || null // Cargar startTime en importación
      }));
    }
  };

  const renderView = () => {
    switch (raceState.activeView) {
      case 'home':
        return <HomeScreen />;
      case 'register':
        return (
          <RunnersManager
            runners={runners}
            onAddRunner={addRunner}
            onUpdateRunner={updateRunner}
            onDeleteRunner={deleteRunner}
            onStartRace={() => changeView('race')}
          />
        );
      case 'race':
        return (
          <>
            <PrecisionTimer 
              currentTime={raceState.currentTime} 
            />
            <RaceControl
              runners={runners}
              onRecordFinish={recordFinish}
              onResetRace={resetRaceData}
              isTimerRunning={raceState.isRunning}
              onTimerRunningChange={(isRunning) => {
                setRaceState(prev => ({ 
                  ...prev, 
                  isRunning: isRunning,
                  startTime: isRunning ? (prev.startTime || performance.now()) : prev.startTime // Mantener startTime si se detiene
                }));
              }}
              currentRaceTime={raceState.currentTime}
            />
            <RaceResultsTable runners={runners} />
          </>
        );
      case 'data':
        return <DataManagement onImportSuccess={handleImportSuccess} />;
      default:
        return <HomeScreen />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <RaceHeader />
      <AppNavigation 
        activeView={raceState.activeView} 
        onChangeView={changeView} 
        isTimerRunning={raceState.isRunning}
      />
      
      <div className="container mx-auto px-4 py-8">
        {renderView()}
      </div>
    </div>
  );
};

export default App;

// DONE